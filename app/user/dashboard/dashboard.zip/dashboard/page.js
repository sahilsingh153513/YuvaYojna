'use client';

import { useState, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  Calendar, 
  Star, 
  MapPin, 
  Clock, 
  DollarSign,
  Users,
  Phone,
  Mail,
  Globe,
  ChevronDown,
  X,
  MessageCircle
} from 'lucide-react';
import TranslatedText from '@/app/language/page';
import MentorChatModal from '../../../components/MentorChatModal';

const UserDashboard = () => {
  const [mentors, setMentors] = useState([]);
  const [filteredMentors, setFilteredMentors] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedExpertise, setSelectedExpertise] = useState('');
  const [selectedExperience, setSelectedExperience] = useState('');
  const [selectedAvailability, setSelectedAvailability] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedMentor, setSelectedMentor] = useState(null);
  const [showMeetingModal, setShowMeetingModal] = useState(false);
  const [showChatModal, setShowChatModal] = useState(false);
  const [isClient, setIsClient] = useState(false);
  const [meetingData, setMeetingData] = useState({
    date: '',
    time: '',
    duration: '30',
    meetingType: 'video',
    message: ''
  });

  // Mock mentor data
  const mockMentors = [
    {
      id: 1,
      firstName: 'Dr. Sarah',
      lastName: 'Johnson',
      email: 'sarah.johnson@example.com',
      phone: '+1-555-0123',
      company: 'TechCorp Solutions',
      position: 'Senior Software Engineer',
      experience: '5-10 years',
      expertise: ['React', 'Node.js', 'AWS', 'JavaScript'],
      location: 'San Francisco, CA',
      bio: 'Experienced full-stack developer with expertise in modern web technologies. Passionate about mentoring junior developers and helping them grow in their careers.',
      linkedin: 'https://linkedin.com/in/sarahjohnson',
      website: 'https://sarahjohnson.dev',
      availability: 'Evenings',
      languages: ['English', 'Spanish'],
      hourlyRate: 75,
      timezone: 'PST',
      rating: 4.8,
      totalSessions: 150,
      isOnline: true
    },
    {
      id: 2,
      firstName: 'Michael',
      lastName: 'Chen',
      email: 'michael.chen@example.com',
      phone: '+1-555-0456',
      company: 'DataFlow Inc',
      position: 'Data Science Lead',
      experience: '10+ years',
      expertise: ['Python', 'Machine Learning', 'SQL', 'TensorFlow'],
      location: 'New York, NY',
      bio: 'Data science expert with 10+ years of experience in machine learning and AI. I love helping others understand complex data concepts and build their careers in data science.',
      linkedin: 'https://linkedin.com/in/michaelchen',
      website: 'https://michaelchen.ai',
      availability: 'Weekends',
      languages: ['English', 'Mandarin'],
      hourlyRate: 90,
      timezone: 'EST',
      rating: 4.9,
      totalSessions: 200,
      isOnline: false
    },
    {
      id: 3,
      firstName: 'Emily',
      lastName: 'Rodriguez',
      email: 'emily.rodriguez@example.com',
      phone: '+1-555-0789',
      company: 'DesignStudio Pro',
      position: 'UX/UI Design Director',
      experience: '5-10 years',
      expertise: ['Figma', 'Adobe Creative Suite', 'User Research', 'Prototyping'],
      location: 'Austin, TX',
      bio: 'Creative UX/UI designer with a passion for creating user-centered designs. I enjoy mentoring designers and helping them develop their creative skills.',
      linkedin: 'https://linkedin.com/in/emilyrodriguez',
      website: 'https://emilyrodriguez.design',
      availability: 'Flexible',
      languages: ['English', 'Spanish'],
      hourlyRate: 65,
      timezone: 'CST',
      rating: 4.7,
      totalSessions: 120,
      isOnline: true
    },
    {
      id: 4,
      firstName: 'David',
      lastName: 'Kim',
      email: 'david.kim@example.com',
      phone: '+1-555-0321',
      company: 'CloudTech Solutions',
      position: 'DevOps Engineer',
      experience: '5-10 years',
      expertise: ['Docker', 'Kubernetes', 'AWS', 'CI/CD'],
      location: 'Seattle, WA',
      bio: 'DevOps specialist with extensive experience in cloud infrastructure and automation. I love helping developers understand DevOps practices and cloud technologies.',
      linkedin: 'https://linkedin.com/in/davidkim',
      website: 'https://davidkim.cloud',
      availability: 'Mornings',
      languages: ['English', 'Korean'],
      hourlyRate: 80,
      timezone: 'PST',
      rating: 4.6,
      totalSessions: 95,
      isOnline: true
    },
    {
      id: 5,
      firstName: 'Lisa',
      lastName: 'Wang',
      email: 'lisa.wang@example.com',
      phone: '+1-555-0654',
      company: 'MobileFirst Apps',
      position: 'Mobile App Developer',
      experience: '3-5 years',
      expertise: ['React Native', 'iOS', 'Android', 'Flutter'],
      location: 'Los Angeles, CA',
      bio: 'Mobile app developer specializing in cross-platform development. I enjoy mentoring developers who want to enter the mobile development space.',
      linkedin: 'https://linkedin.com/in/lisawang',
      website: 'https://lisawang.mobile',
      availability: 'Evenings',
      languages: ['English', 'Chinese'],
      hourlyRate: 70,
      timezone: 'PST',
      rating: 4.5,
      totalSessions: 80,
      isOnline: false
    }
  ];

  const expertiseOptions = [
    'React', 'Node.js', 'Python', 'JavaScript', 'AWS', 'Machine Learning',
    'SQL', 'TensorFlow', 'Figma', 'Adobe Creative Suite', 'User Research',
    'Prototyping', 'Docker', 'Kubernetes', 'CI/CD', 'React Native',
    'iOS', 'Android', 'Flutter', 'Vue.js', 'Angular', 'TypeScript'
  ];

  const experienceOptions = [
    '1-3 years', '3-5 years', '5-10 years', '10+ years'
  ];

  const availabilityOptions = [
    'Mornings', 'Afternoons', 'Evenings', 'Weekends', 'Flexible'
  ];

  useEffect(() => {
    setIsClient(true);
    fetchMentors();
  }, []);

  const fetchMentors = async () => {
    try {
      const response = await fetch('/api/mentors');
      if (response.ok) {
        const data = await response.json();
        setMentors(data.mentors);
        setFilteredMentors(data.mentors);
      } else {
        // Fallback to mock data if API fails
        setMentors(mockMentors);
        setFilteredMentors(mockMentors);
      }
    } catch (error) {
      console.error('Error fetching mentors:', error);
      // Fallback to mock data
      setMentors(mockMentors);
      setFilteredMentors(mockMentors);
    }
  };

  useEffect(() => {
    let filtered = mentors;

    if (searchTerm) {
      filtered = filtered.filter(mentor => 
        mentor.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        mentor.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        mentor.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        mentor.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
        mentor.expertise.some(skill => 
          skill.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }

    if (selectedExpertise) {
      filtered = filtered.filter(mentor => 
        mentor.expertise.includes(selectedExpertise)
      );
    }

    if (selectedExperience) {
      filtered = filtered.filter(mentor => 
        mentor.experience === selectedExperience
      );
    }

    if (selectedAvailability) {
      filtered = filtered.filter(mentor => 
        mentor.availability === selectedAvailability
      );
    }

    setFilteredMentors(filtered);
  }, [searchTerm, selectedExpertise, selectedExperience, selectedAvailability, mentors]);

  const handleScheduleMeeting = (mentor) => {
    setSelectedMentor(mentor);
    setShowMeetingModal(true);
  };

  const handleChatMentor = (mentor) => {
    setSelectedMentor(mentor);
    setShowChatModal(true);
  };

  const handleCloseModal = () => {
    setShowMeetingModal(false);
    setShowChatModal(false);
    setSelectedMentor(null);
    setMeetingData({
      date: '',
      time: '',
      duration: '30',
      meetingType: 'video',
      message: ''
    });
  };

  const handleMeetingSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/meetings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          mentorId: selectedMentor._id || selectedMentor.id,
          userId: 'user123', // In a real app, this would come from authentication
          scheduledDate: meetingData.date,
          startTime: meetingData.time,
          duration: parseInt(meetingData.duration),
          meetingType: meetingData.meetingType,
          requestMessage: meetingData.message,
          title: `Meeting with ${selectedMentor.firstName} ${selectedMentor.lastName}`
        }),
      });
      
      const data = await response.json();
      
      if (response.ok) {
        alert('Meeting request sent successfully!');
        handleCloseModal();
      } else {
        alert(data.error || 'Failed to send meeting request');
      }
    } catch (error) {
      console.error('Error sending meeting request:', error);
      alert('Failed to send meeting request. Please try again.');
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedExpertise('');
    setSelectedExperience('');
    setSelectedAvailability('');
  };

  // Prevent hydration mismatch by not rendering until client-side
  if (!isClient) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F0FDF4' }}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F0FDF4' }}>
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold" style={{ color: '#1F2937' }}>
                <TranslatedText>Find Your Mentor</TranslatedText>
              </h1>
              <p className="text-lg mt-2" style={{ color: '#6B7280' }}>
                <TranslatedText>Connect with experienced professionals and grow your career</TranslatedText>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filters */}
        <div className="bg-white rounded-2xl p-6 mb-8 shadow-sm">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search Bar */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: '#6B7280' }} />
                <input
                  type="text"
                  placeholder="Search mentors by name, company, or expertise..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500"
                  style={{ backgroundColor: 'white', color: '#000000' }}
                  suppressHydrationWarning
                />
              </div>
            </div>

            {/* Filter Button */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center px-6 py-3 border-2 border-gray-200 rounded-xl hover:border-green-500 transition-colors"
              style={{ backgroundColor: 'white', color: '#000000' }}
              suppressHydrationWarning
            >
              <Filter className="w-5 h-5 mr-2" style={{ color: '#6B7280' }} />
              <TranslatedText>Filters</TranslatedText>
              <ChevronDown className={`w-4 h-4 ml-2 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Filter Options */}
          {showFilters && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Expertise Filter */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#000000' }}>
                    <TranslatedText>Expertise</TranslatedText>
                  </label>
                  <select
                    value={selectedExpertise}
                    onChange={(e) => setSelectedExpertise(e.target.value)}
                    className="w-full p-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500"
                    style={{ backgroundColor: 'white', color: '#000000' }}
                    suppressHydrationWarning
                  >
                    <option value="">All Expertise</option>
                    {expertiseOptions.map(expertise => (
                      <option key={expertise} value={expertise}>{expertise}</option>
                    ))}
                  </select>
                </div>

                {/* Experience Filter */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#000000' }}>
                    <TranslatedText>Experience</TranslatedText>
                  </label>
                  <select
                    value={selectedExperience}
                    onChange={(e) => setSelectedExperience(e.target.value)}
                    className="w-full p-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500"
                    style={{ backgroundColor: 'white', color: '#000000' }}
                    suppressHydrationWarning
                  >
                    <option value="">All Experience</option>
                    {experienceOptions.map(exp => (
                      <option key={exp} value={exp}>{exp}</option>
                    ))}
                  </select>
                </div>

                {/* Availability Filter */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#000000' }}>
                    <TranslatedText>Availability</TranslatedText>
                  </label>
                  <select
                    value={selectedAvailability}
                    onChange={(e) => setSelectedAvailability(e.target.value)}
                    className="w-full p-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500"
                    style={{ backgroundColor: 'white', color: '#000000' }}
                    suppressHydrationWarning
                  >
                    <option value="">All Availability</option>
                    {availabilityOptions.map(avail => (
                      <option key={avail} value={avail}>{avail}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Clear Filters */}
              <div className="mt-4 flex justify-end">
                <button
                  onClick={clearFilters}
                  className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 transition-colors"
                >
                  <TranslatedText>Clear All Filters</TranslatedText>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Mentors Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMentors.map(mentor => (
            <div key={mentor.id} className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow">
              {/* Mentor Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg"
                       style={{ backgroundColor: '#16A34A' }}>
                    {mentor.firstName[0]}{mentor.lastName[0]}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold" style={{ color: '#1F2937' }}>
                      {mentor.firstName} {mentor.lastName}
                    </h3>
                    <p className="text-sm" style={{ color: '#6B7280' }}>
                      {mentor.position} at {mentor.company}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${mentor.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                  <span className="text-xs" style={{ color: '#6B7280' }}>
                    {mentor.isOnline ? 'Online' : 'Offline'}
                  </span>
                </div>
              </div>

              {/* Mentor Info */}
              <div className="space-y-3 mb-4">
                <div className="flex items-center text-sm" style={{ color: '#6B7280' }}>
                  <MapPin className="w-4 h-4 mr-2" />
                  {mentor.location}
                </div>
                <div className="flex items-center text-sm" style={{ color: '#6B7280' }}>
                  <Clock className="w-4 h-4 mr-2" />
                  {mentor.availability}
                </div>
                <div className="flex items-center text-sm" style={{ color: '#6B7280' }}>
                  <DollarSign className="w-4 h-4 mr-2" />
                  ${mentor.hourlyRate}/hour
                </div>
                <div className="flex items-center text-sm" style={{ color: '#6B7280' }}>
                  <Star className="w-4 h-4 mr-2" />
                  {mentor.rating} ({mentor.totalSessions} sessions)
                </div>
              </div>

              {/* Expertise Tags */}
              <div className="mb-4">
                <div className="flex flex-wrap gap-2">
                  {mentor.expertise.slice(0, 3).map(skill => (
                    <span
                      key={skill}
                      className="px-3 py-1 text-xs font-medium rounded-full"
                      style={{ backgroundColor: '#F0FDF4', color: '#16A34A' }}
                    >
                      {skill}
                    </span>
                  ))}
                  {mentor.expertise.length > 3 && (
                    <span className="px-3 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-600">
                      +{mentor.expertise.length - 3} more
                    </span>
                  )}
                </div>
              </div>

              {/* Bio Preview */}
              <p className="text-sm mb-4" style={{ color: '#6B7280' }}>
                {mentor.bio.length > 100 ? `${mentor.bio.substring(0, 100)}...` : mentor.bio}
              </p>

              {/* Action Buttons */}
              <div className="flex space-x-2">
                <button
                  onClick={() => handleChatMentor(mentor)}
                  className="flex-1 flex items-center justify-center px-4 py-2 border-2 border-green-500 text-green-600 rounded-xl hover:bg-green-50 transition-colors"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  <TranslatedText>Chat</TranslatedText>
                </button>
                <button
                  onClick={() => handleScheduleMeeting(mentor)}
                  className="flex-1 flex items-center justify-center px-4 py-2 text-white rounded-xl hover:opacity-90 transition-opacity"
                  style={{ backgroundColor: '#16A34A' }}
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  <TranslatedText>Schedule Meeting</TranslatedText>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* No Results */}
        {filteredMentors.length === 0 && (
          <div className="text-center py-12">
            <Users className="w-16 h-16 mx-auto mb-4" style={{ color: '#6B7280' }} />
            <h3 className="text-xl font-semibold mb-2" style={{ color: '#1F2937' }}>
              <TranslatedText>No mentors found</TranslatedText>
            </h3>
            <p className="text-gray-600 mb-4">
              <TranslatedText>Try adjusting your search criteria or filters</TranslatedText>
            </p>
            <button
              onClick={clearFilters}
              className="px-6 py-3 text-white rounded-xl hover:opacity-90 transition-opacity"
              style={{ backgroundColor: '#16A34A' }}
            >
              <TranslatedText>Clear Filters</TranslatedText>
            </button>
          </div>
        )}
      </div>

      {/* Chat Modal */}
      {showChatModal && selectedMentor && (
        <MentorChatModal
          mentor={selectedMentor}
          isOpen={showChatModal}
          onClose={handleCloseModal}
        />
      )}

      {/* Meeting Scheduling Modal */}
      {showMeetingModal && selectedMentor && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold" style={{ color: '#1F2937' }}>
                <TranslatedText>Schedule Meeting with {selectedMentor.firstName} {selectedMentor.lastName}</TranslatedText>
              </h3>
              <button
                onClick={handleCloseModal}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleMeetingSubmit} className="space-y-4">
              <div className="text-center">
                <div className="w-16 h-16 rounded-full flex items-center justify-center text-white font-bold text-2xl mx-auto mb-3"
                     style={{ backgroundColor: '#16A34A' }}>
                  {selectedMentor.firstName[0]}{selectedMentor.lastName[0]}
                </div>
                <p className="text-sm" style={{ color: '#6B7280' }}>
                  {selectedMentor.position} at {selectedMentor.company}
                </p>
                <p className="text-sm font-medium mt-1" style={{ color: '#16A34A' }}>
                  ${selectedMentor.hourlyRate}/hour
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#1F2937' }}>
                    <TranslatedText>Date</TranslatedText>
                  </label>
                  <input
                    type="date"
                    value={meetingData.date}
                    onChange={(e) => setMeetingData({...meetingData, date: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500"
                    required
                    suppressHydrationWarning
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#1F2937' }}>
                    <TranslatedText>Time</TranslatedText>
                  </label>
                  <input
                    type="time"
                    value={meetingData.time}
                    onChange={(e) => setMeetingData({...meetingData, time: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500"
                    required
                    suppressHydrationWarning
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#1F2937' }}>
                    <TranslatedText>Duration</TranslatedText>
                  </label>
                  <select
                    value={meetingData.duration}
                    onChange={(e) => setMeetingData({...meetingData, duration: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500"
                    suppressHydrationWarning
                  >
                    <option value="30">30 minutes</option>
                    <option value="60">1 hour</option>
                    <option value="90">1.5 hours</option>
                    <option value="120">2 hours</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: '#1F2937' }}>
                    <TranslatedText>Meeting Type</TranslatedText>
                  </label>
                  <select
                    value={meetingData.meetingType}
                    onChange={(e) => setMeetingData({...meetingData, meetingType: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500"
                    suppressHydrationWarning
                  >
                    <option value="video">Video Call</option>
                    <option value="phone">Phone Call</option>
                    <option value="in-person">In-Person</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: '#1F2937' }}>
                  <TranslatedText>Message (Optional)</TranslatedText>
                </label>
                <textarea
                  value={meetingData.message}
                  onChange={(e) => setMeetingData({...meetingData, message: e.target.value})}
                  placeholder="Tell the mentor what you'd like to discuss..."
                  rows={3}
                  className="w-full p-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500"
                  suppressHydrationWarning
                />
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  className="w-full flex items-center justify-center px-4 py-3 text-white rounded-xl hover:opacity-90 transition-opacity"
                  style={{ backgroundColor: '#16A34A' }}
                >
                  <Calendar className="w-5 h-5 mr-2" />
                  <TranslatedText>Send Meeting Request</TranslatedText>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserDashboard;
